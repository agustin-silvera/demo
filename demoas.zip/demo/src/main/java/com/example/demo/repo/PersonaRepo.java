package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;


@Repository
public interface PersonaRepo extends CrudRepository<Persona,Integer> {
}
