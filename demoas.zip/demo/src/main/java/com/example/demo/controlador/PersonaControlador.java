package com.example.demo.controlador;

import com.example.demo.serv.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/persona")
public class PersonaControlador {

    @Autowired
    PersonaService personaService;

    @PostMapping("/nuevaPersona")
    public Persona nuevaPersona(@RequestBody Persona persona) {
        return personaService.nuevaPersona(persona);
    }
    @PostMapping("/borrarPersona"){
        del = personaService.borrarPersona(@RequestParam Integer IdPersona);
        return del;
    }
    @PostMapping("/actualizarPersona"){
        public Persona actualizarPersona(@RequestBody Persona persona){
            per=personaService.actualizarPersona(persona);
            return per;
        }
    }


}
